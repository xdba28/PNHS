<?php
session_start(); 
include "db_conn.php";
	
$var = 0;

if(empty($_SESSION['count_checker']) && empty($_SESSION['cell_count'])){
		echo ("<SCRIPT LANGUAGE='JavaScript'>
				var r = confirm('Schedule is not complete. Finish it later!');
				if(r == true){
					window.location.href='index.php';
				}
				else{
					window.location.href='index.php';
				}
				</SCRIPT>");
}
else{
	$var = 1;
}

	if ($_SESSION['count_checker'] != $_SESSION['cell_count'] && $var=1) {
		echo ("<SCRIPT LANGUAGE='JavaScript'>
				var r = confirm('Schedule is not complete. Finish it later!');
				if(r == true){
					window.location.href='index.php';
				}
				else{
					window.location.href='index.php';
				}
				</SCRIPT>");
	}
	else {
		echo ("<SCRIPT LANGUAGE='JavaScript'>
				var r = confirm('Schedule is Full. Save?');
				if(r == true){
					
				}
				else{
				}
				</SCRIPT>");
	}
?>