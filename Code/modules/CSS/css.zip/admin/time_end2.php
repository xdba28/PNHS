<?php
session_start(); 
include "db_conn.php";
$grade = $_SESSION['grade'];
$sub = $_SESSION['sub'];

if($grade==8 || $grade==10){
	$times=array('06:30:00', '07:20:00', '08:10:00', '09:10:00', '10:00:00', '10:50:00', '11:40:00');
    $timee=array('07:20:00', '08:10:00', '09:00:00', '10:00:00', '10:50:00', '11:40:00', '12:30:00');
    $timeee=array('07:20', '08:10', '09:00', '10:00', '10:50', '11:40', '12:30');
}
else{
	$times=array('12:30:00', '01:20:00', '02:10:00', '03:10:00', '04:00:00', '04:50:00', '05:40:00');
    $timee=array('01:20:00', '02:10:00', '03:00:00', '04:00:00', '04:50:00', '05:40:00', '06:30:00');
    $timeee=array('01:20', '02:10', '03:00', '04:00', '04:50', '05:40', '06:30');
}

if(!empty($_POST['time_s'])){
	$time = $_POST['time_s'];
	$_SESSION['time_s'] = $time;
	for ($i=0; $i < 7; $i++) { 
		if($time==$times[$i]){
			break;
		}
	}

if($sub==50010){
	echo'<select class="form-control" name = "time_e" id="" onchange="teacher(this.value)" required>
		<option value="">Select</option>';
		echo '<option value='.$timee[$i].'>'.$timeee[$i].'</option>';
		if($i!=6){
			echo '<option value='.$timee[$i+1].'>'.$timeee[$i+1].'</option>';
		}	
	echo'</select>';
}
else{
	echo'<select class="form-control" name = "time_e" id="" onchange="teacher(this.value)" required>
		<option value="">Select</option>';
	echo '<option value='.$timee[$i].'>'.$timeee[$i].'</option>';	
	echo'</select>';
}
}
?>

<script type="text/javascript">
  function teacher(val){
		$.ajax({
			type: "POST",
			url: "select_teacher.php",
			data: "time_e="+val,
			success: function(data){
				$("#teacher").html(data);
			}
		});
	}
</script>
