<?php 
session_start();
		$_SESSION['screen_width'] = $_POST['width'];
		
 ?>
 
 