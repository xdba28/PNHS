<?php 
	session_start();
	echo $_SESSION['modal'] = 1;
?>