
<?php
include "db_conn.php";
/*$s = mysqli_query($conn, "SELECT * FROM schedule WHERE TIME_END='01:20:00'");

$c=0;
foreach ($s as $r) {
	$arr[$c] = $r['TIME_START'];
	$c++;
}
$j = count($arr);
echo $j;
print_r($arr);
*/

$test = "1324dsa";
$test = (int)$test;
echo $test;
?>