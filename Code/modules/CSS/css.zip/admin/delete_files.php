<?php
$file = fopen("files/teacher7.txt", "w");
$file = fopen("files/subject7.txt", "w");
$file = fopen("files/section7.txt", "w");
$file = fopen("files/days7.txt", "w");
$file = fopen("files/time_start7.txt", "w");
$file = fopen("files/time_end7.txt", "w");

$file = fopen("files/teacher8.txt", "w");
$file = fopen("files/subject8.txt", "w");
$file = fopen("files/section8.txt", "w");
$file = fopen("files/days8.txt", "w");
$file = fopen("files/time_start8.txt", "w");
$file = fopen("files/time_end8.txt", "w");

$file = fopen("files/teacher9.txt", "w");
$file = fopen("files/subject9.txt", "w");
$file = fopen("files/section9.txt", "w");
$file = fopen("files/days9.txt", "w");
$file = fopen("files/time_start9.txt", "w");
$file = fopen("files/time_end9.txt", "w");

$file = fopen("files/teacher10.txt", "w");
$file = fopen("files/subject10.txt", "w");
$file = fopen("files/section10.txt", "w");
$file = fopen("files/days10.txt", "w");
$file = fopen("files/time_start10.txt", "w");
$file = fopen("files/time_end10.txt", "w");

$file = fopen("files/sched_m17.txt", "w");
$file = fopen("files/sched_m27.txt", "w");
$file = fopen("files/sched_m37.txt", "w");

$file = fopen("files/trtd_m17.txt", "w");
$file = fopen("files/trtd_m27.txt", "w");
$file = fopen("files/trtd_m37.txt", "w");

$file = fopen("files/days_m17.txt", "w");
$file = fopen("files/days_m27.txt", "w");
$file = fopen("files/days_m37.txt", "w");
?>