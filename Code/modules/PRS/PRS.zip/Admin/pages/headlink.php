 <head>
        <meta charset="UTF-8">
        <title>PAG-ASA National High School</title>
        <link href="http://fonts.googleapis.com/css?family=Dosis:400,500,700" rel="stylesheet" type="text/css">
        <link rel='stylesheet prefetch' href='../css/bootstrap.min.css'>
        <link rel="icon" href="../img/pnhs_favicon.ico" type="image/x-icon">
        <link rel="stylesheet" href="../css/style.css">
        <link rel="stylesheet" href="../css/w3.css">
		
		<!-- TABLE HEADER DESIGN -->
	<link rel="stylesheet" href="../css/heading.css">
		<!-- Custom Css -->
	<link rel="stylesheet" href="../css/delete.css">
		

		<!-- div button -->
    <link rel="stylesheet" href="../css/divdivflat.css">
    <link rel="stylesheet" href="../css/font-awesome/css/font-awesome.min.css"> 
    <link href="../css/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
	<!-- DataTables Responsive CSS -->
    <link href="../css/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
	<!-- pop up button -->
    <link rel="stylesheet" href="../css/popup.css">
     <link rel="stylesheet" href="../css/notif.css">
    <!--JQUERY-->
	<script src="../jquery/jquery.min.js"></script>
    
	</head>
	
	<style type="text/css">
/* BackToTop button css */
#scroll {
    position:fixed;
    right:10px;
    bottom:10px;
    cursor:pointer;
    width:50px;
    height:50px;
    background-color:#3498db;
    text-indent:-9999px;
    display:none;
    -webkit-border-radius:5px;
    -moz-border-radius:5px;
    border-radius:5px;
}
#scroll span {
    position:absolute;
    top:50%;
    left:50%;
    margin-left:-8px;
    margin-top:-12px;
    height:0;
    width:0;
    border:8px solid transparent;
    border-bottom-color:#ffffff
}
#scroll:hover {
    background-color:#e74c3c;
    opacity:1;
    filter:"alpha(opacity=100)";
    -ms-filter:"alpha(opacity=100)";
}


</style>