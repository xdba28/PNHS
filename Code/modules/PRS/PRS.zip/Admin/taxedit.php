<!DOCTYPE html>
<html lang="en" >
   <?php
    //include("func.php");
    include("session.php");
    ?>
   <?php include("pages/headlink.php");?>
    <body>
        <div id="wrapper">
            <?php include("pages/sidenav.php"); ?>
            <?php include("pages/topnav.php")?>    
            <!---Start Content---->
				<div class="container">
                    
                    <!--Body Start Here-->
					
		<div class="container-fluid" style="height:700px;max-width:100%;margin-right:20px;margin-left:20px;margin-bottom:10px">
        
		
	
			<div class="row">
		<div class="col-lg-12">
		<h3 class="page-header"> <img style="border-radius: 50%;background-color: #fdfdfd " src="../assets/images/tax1.png" width="46px"><font size="6px" face="helvetica"><b>TAX TABLE</b></font></h3>
	 	</div> 
			</div>

					<br>

                <!--======== CONTENT STARTS HERE=============-->			
		
			<div class="row" style=" margin-left: 50px">
			
			<form method="post" action="functions/taxupdate.php">
                <div class="col-lg-12">
                    <div class="panel panel-default" >
                        <div class="panel1" >
                            <img   style="border-radius: 50%;background-color: #fdfdfd " src="../assets/images/tax1.png" width="46px"><font size="6px" face="helvetica">TAX TABLE</font> 
						<a href="taxedit.php"><button type="submit" name="submit" class="btn btn-primary btn-lg" style="float: right;margin-right: 15;"> UPDATE</button></a>
						</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        
			
				
					<table width="100%" class="table table-striped table-bordered table-hover">

										<thead>
								<tr>
									
									<th>
										<p><center>Monthly</center></p>
										<p  style="border-top-style: solid; border-width: 2;"><center>Exemption</center></p>
										<p><center>Percentage</center></p>
									</th>
									
									
									<?php 
									$stat = mysql_query ("Select * from prs_stat_ex group by number asc");
									while($statrow = mysql_fetch_assoc($stat))
										{
											$stat_id = $statrow['stat_id'];
											$exemption = $statrow['exemption'];
											$percentage = $statrow['percentage'];
											$number = $statrow['number'];
									?>
									<th>
										<p><center><?php echo $number;?></center></p>
										<input hidden name="number[]" value="<?php echo $number;?>">
										<input hidden name="stat_id[]" value="<?php echo $stat_id;?>">
										<p><input class="form-control" name="exemption[]" value="<?php echo $exemption;?>"></p>
										<p><input class="form-control" name="percentage[]" value="<?php echo $percentage;?>"></p>
									</th>	
										<?php } ?>
									
								</tr>
										</thead>
                                
									<tbody>
     							
								<?php
								$taxname = mysql_query("Select * from  prs_withholding_tax ");
								
								$tax_name="";
								while ($taxnamerow=mysql_fetch_assoc($taxname))
									{
										$tax_name = $taxnamerow['tax_name'];
								?>
								<tr>
									<input hidden name="name[]" value="<?php echo $tax_name;?>">
									<td><center><?php echo $tax_name; ?></center></td>
								
								
								<?php 
									$taxselect = mysql_query("select * from prs_withholding_tax, prs_tax_amount, prs_stat_ex
																where prs_stat_ex.stat_id=prs_tax_amount.stat_id and prs_withholding_tax.tax_id=prs_tax_amount.tax_id
																and prs_withholding_tax.tax_name='$tax_name'   ");
												while($taxselectrow = mysql_fetch_assoc($taxselect))
												{
													$tax_amount = $taxselectrow['amount_fr'];
													$id = $taxselectrow['id'];
								?>
									<input hidden name="id[]" value="<?php echo $id;?>">
									<td><input class="form-control" name="amount[]" value="<?php echo $tax_amount;?>"></td>
												<?php }?>
								
								</tr>
								<?php }?>		
								
									</tbody>
                            </table>
                         <!-- /.table-responsive -->

                        </div>
                        <!-- /.panel-body -->
                    </div>
            </div>
			</form>
            </div>


        <br>
       
         
	   
    </div>
					<br /> <br /> <br /> <br /> <br /> <br />
					<!--End Body Here-->
                </div>
           <!--End Content--->
			   
			   <?php include("pages/footer.php")?> <!--Footer-->
            </div>
            <script src='../js/jquery.min.js'></script>
            <script src='../js/bootstrap.min.js'></script>
            <script  src="../js/index.js"></script>
			
				<!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

	<!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
        </body>
    </html>