<html>
<?php
include('../../connection.php');

if(!empty($_POST["gsisyear"]))
{	$year = $_POST["gsisyear"];
	$query= mysql_query("SELECT  monthname(date_change) as month FROM  prs_setting where year(date_change) ='$year' AND name_setting='GSIS' group by monthname(date_change) ");
	
	while($row=mysql_fetch_assoc($query))
	{
		
		$month 	   = $row['month'];
	
	?>
	<tr>
	<td><center><?php echo $month?></center></td>
	
	
	<td>
	<?php $query1 =mysql_query("SELECT date_change as changes FROM prs_setting where year(date_change) ='$year' AND name_setting='GSIS' AND monthname(date_change)='$month'");
	while ($datechanges = mysql_fetch_assoc($query1))
	{
		$changes = $datechanges['changes'];
		$changes = date("F d, Y h:i:s A");
	?>
	<center><?php echo $changes;?></center>
	<?php }?>

	</td>	
	
	<td>
	<?php $query2 =mysql_query("SELECT changes as changed FROM prs_setting where year(date_change) ='$year' AND name_setting='GSIS' AND monthname(date_change)='$month'");
	while ($datechanged = mysql_fetch_assoc($query2))
	{
		$changed = $datechanged['changed'];
	?>
	<center><b><?php echo $changed; ?>%</b></center>
	<?php } ?>
	</td>
	
	
		</tr>
	<?php
	}
	
}

?>
</html>