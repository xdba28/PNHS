<!DOCTYPE html>
<html lang="en" >
   <?php
    //include("func.php");
    include("session.php");
   
//Get Info Contribution
$contriget = mysql_query("SELECT prs_gsis.gsis_percentage as percentage, prs_gsis.gsis_id as gsis_id, prs_pagibig.pagibig_id as pagibig_id ,prs_pagibig.pi_amount as amount FROM prs_gsis, prs_pagibig");
	$contcount = mysql_num_rows($contriget);
	$controw=mysql_fetch_assoc($contriget);
	$percentage = $controw['percentage'];
	$amount = $controw['amount'];
	$gsis_id = $controw['gsis_id'];
	$pagibig_id = $controw['pagibig_id'];
	
	$per = "%";
   
//Get Time JS
function get_timeago( $ptime )
{
    $estimate_time = time() - $ptime;

    if( $estimate_time < 1 )
    {
        return 'less than minute ago';
    }

    $condition = array( 
                12 * 30 * 24 * 60 * 60  =>  'year',
                30 * 24 * 60 * 60       =>  'month',
                24 * 60 * 60            =>  'day',
                60 * 60                 =>  'hour',
                60                      =>  'minute',
                1                       =>  'second'
    );

    foreach( $condition as $secs => $str )
    {
        $d = $estimate_time / $secs;

        if( $d >= 1 )
        {
            $r = round( $d );
            return  $r . ' ' . $str . ( $r > 1 ? 's' : '' ) . ' ago';
        }
    }
}   
	?>
   <?php include("pages/headlink.php");?>
    <body>
        <div id="wrapper">
            <?php include("pages/sidenav.php"); ?>
            <?php include("pages/topnav.php")?>    
            <!---Start Content---->
				<div class="container">
                    <!--Body Start Here-->
							
        <div class="container-fluid" style="height:700px;max-width:100%;margin-right:20px;margin-left:20px;margin-bottom:10px">
        
		
						
				
			<div class="row">
		<div class="col-lg-12">
		<h3 class="page-header"><img  class="w3-hover-light-blue" style="margin-right: 2;border-radius: 50%;background-color: #fdfdfd " src="../assets/images/setting.png" width="46px">SETTINGS</h3>
	 	</div>
			</div>


                <!--======== CONTENT STARTS HERE=============-->			
			 
			 			
			 <div class="col-lg-12">
                   <div class="panel panel-primary" style="width:700px; float:left;">
                        <div class="panel1">
                            <img  class="w3-hover-light-blue" style="margin-right: 2;border-radius: 50%;background-color: #fdfdfd " src="../assets/images/setting.png" width="40px">
							<font size="4"><b>SETTINGS</b></font>
                        </div>
                        <div class="panel-body">
                           <table>
									<tbody>
									<form method="post" action="functions/allowanceupdate.php">
									<tr>
									<td><b>Allowance:&nbsp;</b></td>
									<?php
										 $qry1 = mysql_query("SELECT * FROM prs_allowance");
										 $num = mysql_num_rows($qry1);
   
										while($row1 = mysql_fetch_assoc($qry1))
										{
											$allowance = $row1['allowance'];
										}

									
										 if($num > 0)
										 {
									?>
									<td><input class="form-control" type="text" name="allowance" value="<?php echo $allowance;?>" required></td>
									<?php } else{?>
									
									<td><input class="form-control" type="text" name="allowance" placeholder="Insert Allowance"  required></td>
									<?php }?>

									<td>&nbsp;<button type="submit" name="allowancesubmit" class="btn btn-primary">Update</button></td>
									</tr>
									</form>
									
									</tbody>
						   </table>

                        </div>
						
                        
						
						<div class="divdivflat">
									<table>
							<tbody>
								<h4><font size="5"><b>SALARY MEMO</b></font></h4>

									<form method="post" action="functions/salmemoupdate.php">
								<tr>
										<td><b>Salary Memo:</b></td>
									<td>
									
										<select class="form-control" style="width:200px;" name="memo">
										<?php 
											$memo =mysql_query ("Select * FROM prs_salary_memo");
												while($memorow=mysql_fetch_assoc($memo))
												{
													$memoid = $memorow['sal_memo_id'];
													$memos = $memorow['salary_memo'];
										?>
                                                <option value="<?php echo $memoid; ?>"><?php echo $memos; ?></option>
										<?php } ?>
										</select>
									</td>
									<td>&nbsp;<button type="submit" name="memosubmit" class="btn btn-primary">Update</button></td>
								&nbsp;&nbsp; 
								<?php 
										$saldate = mysql_query("SELECT * FROM prs_setting where special_attribute='Salary Memo' group by date_change DESC LIMIT 1 ");
										$saldaterow = mysql_fetch_assoc($saldate);
											$changes = $saldaterow['changes'];
											$salname = $saldaterow['name_setting'];
											$salchange = get_timeago(strtotime($saldaterow['date_change']));
										
								?>
										
								</tr>
								<font size="1" color="red">*Last Updated: <?php echo $salname ?> <?php echo $changes ?> | <?php echo $salchange ?> </font>
										</form>
							</tbody>
									</table>
						
						</div>
						<div class="divdivflat">
						<h4><font size="5"><b>Contribution</b></font></h4>
						 <blockquote>
                            <table>
									<tbody>
									<form method="post" action="functions/contriupdate.php">
									
									
									
									<?php 
									if($num > 0)
									{
							?>		
									<tr><td> &nbsp </td><td style="border-style: outset;border-color: #48a5f1;"><center><label class=" control-label">GSIS</td></label></center> </tr>
									<tr>
										<td><center><img src="..\assets\images\gsis.png"  width="55" />&nbsp&nbsp </center></td>
											<input hidden name="gsis_id" value="<?php echo $gsis_id;?>">
										<td><input class="form-control" type="text" name="gsis" value="<?php echo $percentage."%";?>"></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<tr><td> &nbsp </td><td style="border-style: outset;border-color: #48a5f1;"><center> <label class=" control-label">PAGIBIG</td></label></center> </tr>
											<td><center><img src="..\assets\images\pibig.png"  width="55" /> &nbsp&nbsp</center></td> 
											<input hidden name="pagibig_id" value="<?php echo $pagibig_id;?>">
											<td><input class="form-control" name="pi" type="text" value="<?php echo $amount;?>"></td>
									</tr>
									<?php } else{?>
									
									<tr><td> &nbsp </td><td style="border-style: outset;border-color: #48a5f1;"><center><label class=" control-label">GSIS</td></label></center> </tr>
									<tr>
										<td><center><img src="..\assets\images\gsis.png"  width="55" />&nbsp&nbsp </center></td>
										
										<td><input class="form-control" type="text" name="gsis" value="" placeholder="GSIS PERCENTAGE"></td>
									</tr>
									<tr>
										<td>&nbsp;</td>
									</tr>
									<tr>
										<tr><td> &nbsp </td><td style="border-style: outset;border-color: #48a5f1;"><center> <label class=" control-label">PAGIBIG</td></label></center> </tr>
											<td><center><img src="..\assets\images\pibig.png"  width="55" /> &nbsp&nbsp</center></td> 
											<td><input class="form-control" name="pi" type="text" value="" placeholder="PAGIBIG AMOUNT"></td>
									</tr>
									
									<?php } ?>
								</tbody>
									</table>
									
									 <div class="panel-body">
                            <!-- Button trigger modal -->
                            <i>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</i>
							<button class="btn btn-primary btn-lg" type="submit" name="submit1">
                                UPDATE
                            </button>
									
									
									</form>
									</tbody>
									</table>
						</blockquote>
				</div>
						</div>
						
						<!--====SIDEBAR TAB===-->
						
						<div class="panel-body" style="width:300px; float: right;">
                            <div class="list-group">
                                <a href="ph_table_edit.php" class="list-group-item">
                                    <i class="fa fa-table fa-fw"></i> PhilHealth
                                    
                                </a>
                                <a href="taxedit.php" class="list-group-item">
                                    <i class="fa fa-table fa-fw"></i> Tax (BIR)
                                    
                                </a>
                                <a href="salmemedit.php" class="list-group-item">
                                    <i class="fa fa-table fa-fw"></i> Salary Memo
                                   
                                </a>
                            </div>
						</div>

						<div>
							<div class="panel-body" style="width:300px; float: right;">
                           <b><i class="fa fa-long-arrow-right fa-fw"></i>REDIRECTION</b>
						   <div class="list-group">
                                <a target="_new" href="https://www.philhealth.gov.ph/partners/employers/contri_tbl.html
" class="list-group-item">
                                    <i class="fa fa-external-link fa-fw"></i> PhilHealth
                                    
                                </a>
                                <a target="_new" href="https://www.bir.gov.ph/index.php/tax-information/withholding-tax.html" class="list-group-item">
                                    <i class="fa fa-external-link fa-fw"></i> Tax (BIR)
                                    
                                </a>
                                <a target="_new" href="salmemedit.php" class="list-group-item">
                                    <i class="fa fa-external-link fa-fw"></i> Salary Memo
                                   
                                </a>
                            </div>
							</div>
						</div>
					</div>
			 </div>
			
			<!--======== CONTENT ENDS HERE=============-->		
       
         </div>
					<br>
					<br>
			<!--End Body Here-->
                </div>
           <!--End Content--->
			   
			   <?php include("pages/footer.php")?> <!--Footer-->
            </div>
            <script src='../js/jquery.min.js'></script>
            <script src='../js/bootstrap.min.js'></script>
            <script  src="../js/index.js"></script>
			
				<!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

	<!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
        </body>
    </html>