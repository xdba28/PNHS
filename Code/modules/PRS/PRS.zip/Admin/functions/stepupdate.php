<?php
include('../../connection.php');
 include('../../sanitise.php');

if (isset($_POST['submit3'])) {
	
			 	 $emp_No= sanitise($_POST['emp_id']);
				 $grade= sanitise($_POST['grade']);
				 $step= sanitise($_POST['step']);
					 $sal_id= sanitise($_POST['sal_id']);
				 
				 
				 $qry= mysql_query ("
									SELECT * FROM pims_personnel, prs_salary_record
															  where  pims_personnel.emp_No='$emp_No' 
															  AND pims_personnel.emp_No=prs_salary_record.emp_No
                                      ");


					if(mysql_num_rows($qry) > 0)
					{
					$qry2= mysql_query("UPDATE prs_salary_record SET salary_id = '$step', grade_id='$grade' where sal_rec_id='$sal_id'");	
					echo "<script>alert('STEP AND GRADE HAS BEEN UPDATED'); </script>";
					echo "<script> window.location='../../admin/profile.php?emp_id=".$emp_No."' </script>";
					
					}
					else
					{
					$qry1= mysql_query("INSERT INTO prs_salary_record ( salary_id, grade_id, emp_No) values ('$step','$grade','$emp_No')");
					echo "<script>alert('STEP AND GRADE HAS BEED ADDED'); </script>";
					echo "<script> window.location='../../admin/profile.php?emp_id=".$emp_No."' </script>";
					}
					
					
				

}
?>


