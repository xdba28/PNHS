<?php
include('../../connection.php');
 include('../../sanitise.php');

if (isset($_POST['submit1'])) {
	
	
	$ids = array_keys($_POST['salary']);
  foreach ($ids as $index) {
	  
	  
	  $sql =("UPDATE prs_salary 
			SET   amount = '".$_POST['amount'][$index]."'
			WHERE salary_id='".$_POST['salary'][$index]."'	
			");
	  
			$result=mysql_query($sql)or 
    die ("Error"); 		  }
	
	
	if($sql){
					echo "<script>alert('Salary Memo Has Been Updated!'); </script>";
					echo "<script> window.location='../../Admin/salarymemo.php' </script>";
					
				}else{
					echo "<script>alert('Error!'); </script>";
				}
							 }

?>


