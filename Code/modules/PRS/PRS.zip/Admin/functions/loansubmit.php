<?php
 
 include('../../connection.php');
 include('../../sanitise.php');

 
if(isset($_POST['submit'])){
//database connection

								  
				 
			     $emp_No= sanitise($_POST['emp_id']);
				 $loan_name= sanitise($_POST['loanname']);
				 $loan_amount= sanitise($_POST['loanamount']);
				 $start= sanitise($_POST['start']);
				 $end= sanitise($_POST['end']);
				 
						
				// Build example data
			
			
				$ongoing = 'ONGOING';
			
			$qry = ("INSERT INTO prs_loan( loan_name, loan_amount, date_start, date_end, loan_status, emp_no) 
								VALUES ('$loan_name', '$loan_amount', '$start', '$end', '$ongoing', '$emp_No')");			
				
	

	
				 $result = mysql_query($qry) or die("Failed Sql Query");

				

				
				if($result){
					echo "<script>alert('Loan Has Been Added!'); </script>";
					echo "<script> window.location='../../admin/profile.php?emp_id=".$emp_No."' </script>";
					
				}else{
					echo "<script>alert('Error!'); </script>";
				}
 
				

}
				
				//header('Location: ../../../profile.php');
				    

?>						