<?php
		include('../../connection.php');

		
		if(isset($_POST['memosubmit']))
		{		$memo = $_POST['memo'];
                
				mysql_query("set autocommit=0");
                mysql_query("start transaction");
                mysql_query("LOCK TABLES prs_setting,prs_salary_record WRITE"); // LOCK mo muna yun mga tables na included sa transaction, yung mga update and insert tables
				$memoinsert = mysql_query ("INSERT INTO prs_setting (name_setting, special_attribute, changes) VALUES('SALARY MEMO', 'Salary Memo' ,'$memo')");
                if($memoinsert){ //ichecheck if na isnert ba if oo pasok siya dito if hindi dun sa baba
                    $emp = mysql_query("SELECT * FROM pims_personnel");
                    $x=0;	
                    $r=0;
                    while($emprow= mysql_fetch_assoc($emp))
                    {	
                        $emp_No = $emprow['emp_No'];
                        $stepselect = mysql_query("SELECT prs_salary.step as step, prs_grade.grade as grade FROM pims_personnel, prs_salary_memo, prs_salary, prs_grade, prs_salary_record
                        WHERE prs_salary_memo.sal_memo_id = prs_salary.sal_memo_id
                        AND   prs_grade.grade_id = prs_salary.grade_id
                        AND   prs_salary.salary_id = prs_salary_record.salary_id
                        AND   prs_grade.grade_id = prs_salary_record.grade_id
                        AND   pims_personnel.emp_No = prs_salary_record.emp_No
                        AND   pims_personnel.emp_No = '$emp_No'"); 
                        while($steprow=mysql_fetch_assoc($stepselect))
                        {
                            $step1 = $steprow['step'];
                            $grade1 = $steprow['grade'];
                            $select = mysql_query("SELECT * FROM prs_salary, prs_salary_memo, prs_grade								   
                            WHERE prs_salary_memo.sal_memo_id = prs_salary.sal_memo_id
                            AND   prs_grade.grade_id = prs_salary.grade_id
                            AND   prs_salary_memo.sal_memo_id='$memo'
                            AND   prs_salary.step = '$step1'
                            AND   prs_grade.grade = '$grade1'");
                           $step ="";
                           while($selectrow=mysql_fetch_assoc($select))
                           {
                                $sal_id = $selectrow['salary_id'];
                                $grade_id = $selectrow['grade_id'];
                                $getidsal = mysql_query("SELECT * FROM pims_personnel, prs_salary_record where pims_personnel.emp_No='$emp_No' and pims_personnel.emp_No=prs_salary_record.emp_No");
                                $w=0;// Kaylangan mo kasing gawing array yung results query mo kasi maraming update ang nangyayare dun. kung hindi mo siya gagawing array yung final  update lang siya maga base.
                                while($getrec_row =mysql_fetch_assoc($getidsal))
                                {
                                    $rec_id = $getrec_row['sal_rec_id'];
                                    $update = ("UPDATE prs_salary_record set salary_id ='$sal_id' , grade_id='$grade_id' WHERE sal_rec_id='$rec_id'");
                                    $results = mysql_query($update) or die("Failed Sql Query");
                                    //r=Right , x=Wrong
                                    if($results[$w]){
                                        $r++; //If nangyare yung update[w] dadagdag yung right
                                    }else{
                                        $x++; //else dadagdag yung wrong
                                    }
                                    $w++;
                                }
                           }

                        }
                        
				    }
                    if($x==0){ //Kung walang maling update maga commit na siya. TANDAAN! Isang transaction isang commit lang.
                        mysql_query("COMMIT");
                        echo "<script>alert('Salary Memo Has Been Updated For This Year!'); </script>";
                        echo "<script> window.location='../../Admin/setting.php' </script>";

                    }else{ // Else kung kahit isang maling update lang rollback na siya walang maling data sa database na papasok
                        mysql_query("ROLLBACK");
                        echo "<script>alert('Error Updating Salary Memo!'); </script>";
                        echo "<script> window.location='../../Admin/setting.php' </script>"; // PS Mag redirect ka parati kahit error para walang makita ang user na 'Undefined Chenelen' XD
                    }
                }else{ //If hindi na isnert maga rollback siya meaning walang changes sa database. safe ang data mo
                     mysql_query("ROLBACK");
                     echo "<script>alert('Error Setting Salary Memo!'); </script>";
                        echo "<script> window.location='../../Admin/setting.php' </script>";
                }
                mysql_query("UNLOCK TABLES");
				
		}

?>