<?php
 
 include('../../connection.php');
 include('../../sanitise.php');

 
if(isset($_POST['submit1'])){
//database connection

								  
				 
			     
				 $gsis= sanitise($_POST['gsis']);
				 $pi= sanitise($_POST['pi']);
				 $gsis_id= sanitise($_POST['gsis_id']);
				 $pagibig_id= sanitise($_POST['pagibig_id']);
				 
				  $qry = mysql_query("SELECT prs_gsis.gsis_percentage as percentage, prs_pagibig.pi_amount as amount FROM prs_gsis, prs_pagibig");
				  $num = mysql_num_rows($qry);
	
				  if($num > 0)
				  {
					  $qry = ("
						UPDATE prs_pagibig, prs_gsis
						  SET prs_pagibig.pi_amount='$pi', prs_gsis.gsis_percentage='$gsis'
                          where prs_pagibig.pagibig_id = '$pagibig_id' AND prs_gsis.gsis_id='$gsis_id'
						");
					  
					  $insertup1 = mysql_query("INSERT INTO prs_setting(name_setting, changes) VALUES('GSIS', '$gsis')");
					  $insertup2 = mysql_query("INSERT INTO prs_setting(name_setting, changes) VALUES('PAGIBIG', '$pi')");
					  
				 $result = mysql_query($qry) or die("Failed Sql Query");

				if($result){
					echo "<script>alert('Contribution Has Been Updated!'); </script>";
					echo "<script> window.location='../../Admin/setting.php' </script>";
					
				}else{
					echo "<script>alert('Error!'); </script>";
				     }
 
				  } else {
					  
							
					  $insertup3 = mysql_query("INSERT INTO prs_setting(name_setting, changes) VALUES('GSIS', '$gsis')");
					  
					  $insertup4 = mysql_query("INSERT INTO prs_setting(name_setting, changes) VALUES('PAGIBIG', '$pi')");
					  
					       $qry1 = mysql_query(" INSERT INTO prs_gsis(gsis_percentage) values('$gsis')
												");
						   $qry2 = (" INSERT INTO prs_pagibig(pi_amount) values('$pi')
												");
							$result1 = mysql_query($qry2) or die("Failed Sql Query");
							
							if($result1){
					echo "<script>alert('Contribution Has Been Added!'); </script>";
					echo "<script> window.location='../../Admin/setting.php' </script>";
					
							}else{
					echo "<script>alert('Error!'); </script>";
								 }
			
				}
				
				 
				

}
				
				//header('Location: ../../../profile.php');
				    

?>						