<?php
include('../../connection.php');
 include('../../sanitise.php');

if (isset($_POST['submit1'])) {
	
	$petmalu = sanitise($_POST['petmalu']);
	
	

	$set = mysql_query("select count(date_change) as countt from prs_salary_history where his_sal_memo='$petmalu' and year(date_change)= year(now()) and month(date_change)= month(now()) "); 
	$setrow = mysql_fetch_assoc($set);
	$countt = $setrow['countt'];
	
 
	
	if($countt == 0)
	{
		$r=0;
		$w=0;
	$ids = array_keys($_POST['id']);
	mysql_query("set automcommit=0");
	mysql_query("start transaction");
	mysql_query("LOCK TABLE prs_salary, prs_salary_history WRITE");
  foreach ($ids as $index) {
	  
	  
	  $sql = ("UPDATE prs_salary 
	  SET amount ='".$_POST['step'][$index]."'
	  WHERE salary_id='".$_POST['id'][$index]."'");
	  $result=mysql_query($sql)or die ("Error"); 
	  if($result){
		  $r++;
	  }else{
		  $w++;
	  }
	 }
	
	  $memoinsert =mysql_query("INSERT INTO prs_salary_history(his_sal_memo) 
	  values ( '$petmalu') ");
	

//	$idx = array_keys($_POST['his_grade']);
//  foreach ($idx as $index) {
	  
//	  $memoinsert = ("INSERT INTO prs_salary_history(his_step, his_amount, his_grade, his_sal_memo) 
//	  values ( '".$_POST['salsteps'][$index]."', '".$_POST['step'][$index]."', 
//	  '".$_POST['salgrade'][$index]."', '".$_POST['salmemo'][$index]."') ");
//	  $diedie=mysql_query($memoinsert)or 
		
//  }
	
	
  if($w>=1){
	  mysql_query("ROLLBACK");
	  echo "<script>alert('Error!'); </script>";
  }else{
	  mysql_query("COMMIT");
	  echo "<script>alert('Salary Memo Has Been Updated!'); </script>";
	  echo "<script> window.location='../../Admin/salmemedit.php' </script>";
  }
mysql_query("UNLOCK TABLES");
				
} else 
	{
			echo "<script>alert('You Already Updated Salary Memo!'); </script>";
			echo "<script> window.location='../../Admin/salmemedit.php' </script>";
	}
  
  }
  
  
						

?>


