<?php
 
 include('../../connection.php');
 include('../../sanitise.php');

 
if(isset($_POST['allowancesubmit'])){
//database connection

					$allowance= sanitise($_POST['allowance']);
				 			  
				 $qry1 = mysql_query("SELECT * FROM prs_allowance");
				
				$num = mysql_num_rows($qry1);
				 
				 if($num > 0)
				 {
						$insertup = mysql_query("INSERT INTO prs_setting(name_setting, changes) VALUES('Allowance', '$allowance')");
					$qry = ("
						UPDATE prs_allowance
						  SET prs_allowance.allowance='$allowance'
                        ");
						
	
				 $result = mysql_query($qry) or die("Failed Sql Query");
						
					 if($result){
					echo "<script>alert('Allowance Has Been Updated!'); </script>";
					echo "<script> window.location='../../Admin/setting.php' </script>";
					
										}else{
												echo "<script>alert('Error!'); </script>";
											 }
			

			} else {
							$insertup1 = mysql_query("INSERT INTO prs_setting(name_setting, changes) VALUES('Allowance', '$allowance')");
							
							$qry3 = (" INSERT INTO prs_allowance(allowance) values ('$allowance')
												"); 
												
									$result1 = mysql_query($qry3) or die("Failed Sql Query");
									
						if($result1){
					echo "<script>alert('Allowance Has Been ADDED!'); </script>";
					echo "<script> window.location='../../Admin/setting.php' </script>";
					
										}else{
												echo "<script>alert('Error!'); </script>";
											 }
							
						}
			     
				 
}
				    

?>						