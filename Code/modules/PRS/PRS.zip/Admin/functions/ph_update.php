<?php
include('../../connection.php');
 include('../../sanitise.php');

if (isset($_POST['submit1'])) {
	
	
	$phcheck= mysql_query("Select count(change_date) as count from prs_ph_change where month(change_date)=month(now()) and year(change_date)=year(now()) ");
	$phrow = mysql_fetch_assoc($phcheck);
	$phnum = $phrow['count'];
	
	if ($phnum == 0)
	{
	
	
	$sql1 = mysql_query("INSERT INTO prs_ph_change(change_share1) VALUES ('date')");  
	
	
	$ids = array_keys($_POST['ph_range_fr']);
  foreach ($ids as $index) {
		
	  
//	$sql1 = mysql_query("INSERT INTO prs_ph_change(change_range_fr, change_range_to, change_salary_base, change_monthly_premium, change_share, change_share1) VALUES ('".$_POST['ph_range_fr'][$index]."','".$_POST['ph_range_to'][$index]."','".$_POST['ph_salary_base'][$index]."','".$_POST['ph_total_monthly_premium'][$index]."','".$_POST['ph_share'][$index]."','".$_POST['ph_share1'][$index]."')");  
	  
    
	$sql = "UPDATE prs_philhealth SET ph_range_fr='".$_POST['ph_range_fr'][$index]."', ph_range_to='".$_POST['ph_range_to'][$index]."',
	ph_salary_base='".$_POST['ph_salary_base'][$index]."', ph_total_monthly_premium='".$_POST['ph_total_monthly_premium'][$index]."', 
	ph_employee_share='".$_POST['ph_share'][$index]."', ph_employee_share1='".$_POST['ph_share1'][$index]."'
	WHERE philhealth_id='".$_POST['ph_id'][$index]."'";
    $result=mysql_query($sql)or 
    die ("Error"); 
								
							}
							
							
							 if($result){
					echo "<script>alert('PhilHealth Table Has Been Updated!'); </script>";
					echo "<script> window.location='../../Admin/ph_table_edit.php' </script>";
					
				}else{
					echo "<script>alert('Error!'); </script>";
				}
								
	} else {
				echo "<script>alert('You Can Only Update PhilHealth Table Once  amount!'); </script>";
				echo "<script> window.location='../../Admin/ph_table_edit.php' </script>";
					
			}
								
								
								
								
								
								
								
								
								}
							

?>


