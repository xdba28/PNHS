<?php
include('../../connection.php');
 include('../../sanitise.php');

if (isset($_POST['submit'])) {
	
	
	$taxinsert = mysql_query("INSERT INTO prs_tax_change( change_fr) VALUES('this')");

//	$idx = array_keys($_POST['amount']);
 // foreach ($idx as $index) {
//	$taxinsert = mysql_query("INSERT INTO prs_tax_change( change_fr, exemption,  tax_percentage, tax_number) VALUES('".$_POST['amount'][$index]."','".$_POST['exemption'][$index]."','".$_POST['percentage'][$index]."')");  
 // }

	//start of update
	//exemption='".$_POST['exemption'][$index]."',
	
	$ids = array_keys($_POST['stat_id']);
  foreach ($ids as $index) {

  $sql = "UPDATE  prs_stat_ex SET percentage='".$_POST['percentage'][$index]."',  exemption='".$_POST['exemption'][$index]."'
	WHERE stat_id='".$_POST['stat_id'][$index]."'";
    $result=mysql_query($sql)or 
    die ("Error"); 
	
	}
	
	
	$id = array_keys($_POST['id']);
  foreach ($id as $index) {
	$sql1 = "UPDATE  prs_tax_amount SET amount_fr='".$_POST['amount'][$index]."'
	WHERE id='".$_POST['id'][$index]."'";
    $result1=mysql_query($sql1)or 
    die ("Error"); }
  
   
  
   
   if($result1){
					echo "<script>alert('Tax Table Has Been Updated!'); </script>";
					echo "<script> window.location='../../Admin/taxedit.php' </script>";
					
				}else{
					echo "<script>alert('Error!'); </script>";
				}
  
 

	
  
}
  
							

?>


