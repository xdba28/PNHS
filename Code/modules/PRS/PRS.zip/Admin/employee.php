<!DOCTYPE html>
<html lang="en" >
   <?php
    //include("func.php");
    include("session.php");
    $qry= mysql_query(" SELECT * FROM pims_personnel, pims_employment_records 
						Where pims_personnel.emp_No=pims_employment_records.emp_No
					")
	?>
   <?php include("pages/headlink.php");?>
    <body>
        <div id="wrapper">
            <?php include("pages/sidenav.php"); ?>
            <?php include("pages/topnav.php")?>    
            <!---Body Start Content---->
				
				<div class="container">
                    <br>
               
                <!--======== CONTENT STARTS HERE=============-->			
		 
					
			<div class="row">
				
             
			 <div class="col-lg-10">
                    <div class="panel panel-default">
                        <div class="panel1">
                          <font face="helvetica" size="6px">  PERSONNEL LIST </font>
						</div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        
<form>
					<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">

							    	<thead>
                                    <tr>
									
                                        <th><center><font size="4">Name</font></center></th>
										<th><center>Employee Type</center></th>
                                        <th><center>Action</center></th>
                                        
                                    </tr>
                                    </thead>
                                    
                                    
				
									<tbody>
     						
								<tr class="gradeA">
                                       <!--input hidden name="employee_id" id="employee_id" ></input-->
						<?php
							while($row= mysql_fetch_assoc($qry))
							{
								$emp_No = $row['emp_No'];
								$fname = $row['P_fname'];
								$mname = $row['P_mname'];
								$lname = $row['P_lname'];
								$extension = $row['P_extension_name'];
								$role  = $row['faculty_type'];
								
							
								
						?>				
										<td><font face="helvetica" size="4px"><?php echo $lname ?>, <?php echo $fname ?> <?php echo $mname ?> <?php echo $extension ?>
						<?php				
						$new = mysql_query	("SELECT * FROM pims_personnel, prs_salary_record, prs_salary, prs_grade
															  where  pims_personnel.emp_No='$emp_No' 
															  AND pims_personnel.emp_No=prs_salary_record.emp_No
                                                              AND prs_grade.grade_id=prs_salary_record.grade_id
                                                              AND prs_salary.salary_id=prs_salary_record.salary_id");
											$new1=mysql_num_rows($new);
											
						$infonew = mysql_query("Select count(register) as counts from prs_add_info, pims_personnel where pims_personnel.emp_No=prs_add_info.emp_No and pims_personnel.emp_No='$emp_No'");
						$inforow = mysql_fetch_assoc($infonew);
						$infonum = $inforow['counts'];
											if($new1 == 0 && $infonum == 0)
											{
					     ?>
										<font size="2" style="color: red; text-shadow: 2px 2px #a99e9e"><b>NEW</b></font>
											<?php } elseif($new1 == 0) { ?>
												<img src="../assets/images/purple.png" style="width: 20px;height: 20px;border-radius: 50%;">
											<?php }  elseif ($infonum == 0){ ?>
												<img src="../assets/images/blue.png" style="width: 20px;height: 20px;border-radius: 50%;">
											<?php } ?>
										</font>
										</td>
                                        
										
										
										<td><center><font face="helvetica" size="4px"><?php echo $role ?></font></center></td>
                                        
								<td align="center">
						         <a class="btn btn-primary"  href="profile.php?emp_id=<?php echo $row["emp_No"]; ?>">Account</a>
                                </td>
							    </tr> 
								
								
								
                          <?php } ?>        
                          
                              </tbody>
                            
							</table>
                           <!-- /.table-responsive -->
</form>
                        </div>
                        <!-- /.panel-body -->
                    </div>
            </div>	
			
			<div class="col-lg-2" style="float: right;">
				<div   class="panel1" style="position: fixed; padding: 5px">
					
					<font>New Employee: </font>
					<font size="2" style="color: red; text-shadow: 2px 2px #a99e9e"><b>NEW</b></font>
						<br />
					<font>Basic Salary :</font>
					<img src="../assets/images/purple.png" style=" width: 20px;height: 20px;border-radius: 50%;">
						<br />
					<font>Tax Information :</font>
					<img src="../assets/images/blue.png" style=" width: 20px;height: 20px;border-radius: 50%;">
				</div>
			</div>
			
			</div>
 
 <!---End--->
			<br><br><br>	
			    </div>
           <!--Body End Content--->
			   
			   <?php include("pages/footer.php")?> <!--Footer-->
            </div>
            <script src='../js/jquery.min.js'></script>
            <script src='../js/bootstrap.min.js'></script>
            <script  src="../js/index.js"></script>
			
				<!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>
	
<script>
    $(function () {
  $('[data-tooltip="tooltip"]').tooltip()
	});
</script>
	
	<!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
        </body>
    </html>