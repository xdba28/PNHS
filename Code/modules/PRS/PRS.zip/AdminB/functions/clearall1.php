<?php
 
 include('../../connection.php');
 include('../../sanitise.php');

 
if(isset($_POST['submit'])){
//database connection


			$emp = mysql_query("SELECT * FROM pims_personnel, pims_employment_records, prs_salary_record, prs_allowance, prs_salary
						Where pims_personnel.emp_No=pims_employment_records.emp_No
						AND pims_employment_records.faculty_type='Non Teaching'
						AND pims_personnel.emp_No=prs_salary_record.emp_No
						AND prs_salary.salary_id = prs_salary_record.salary_id");
			while($emprow = mysql_fetch_assoc($emp))
			{
				$emp_No = $emprow['emp_No'];
				
				$clear = 0;
				
				$insert = mysql_query("INSERT INTO prs_mtr (emp_No, monthly_cost, time) values ('$emp_No', '0', '0')");
				
				
			}
				

				
					echo "<script>alert('Late Deduction Has Been  Updated For This Month!'); </script>";
					echo "<script> window.location='../teaching.php' </script>";
					
		
				
}
				
				//header('Location: ../../../profile.php');
				    

?>						