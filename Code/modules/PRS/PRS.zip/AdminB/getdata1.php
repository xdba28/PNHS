<html>
<?php
include('../connection.php');

if(!empty($_POST["year"]))
{	$year = $_POST["year"];
	$query= mysql_query("SELECT  monthname(time_issued) as month, count(emp_No) as total FROM  prs_mtr where year(time_issued) ='$year' group by monthname(time_issued) ");
	
	while($row=mysql_fetch_assoc($query))
	{
		
		$total 	   = $row['total'];
		$month 	   = $row['month'];
	
	?>
	
	<td><center><a href="sort_month.php?month=<?php echo $month?>&&year=<?php echo $year?>" target="_blank"><?php echo $month?></a></option></center></td>
	<td><center><?php echo $total ?></center></td>	
	<?php
	}
	
}

?>
</html>