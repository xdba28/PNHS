              <footer class="w3-theme-bd5">
                    <div class="container">
                        <div class="col-lg-3 col-md-3">
                            <h3 class="h3">PNHS</h3>
                            <h6>All Rights Reserved &copy; 2018</h6>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <h1 class="h3">ADDRESS</h1>
                            <h6><b>Pag-asa National Highschool</b><br><span>PNHS Building, Rawis, East Service<br>  Road, Legazpi City, PH 2424</span></h6>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <h3 class="h3">CONTACT US</h3>
                            <h6 class="w3-justify">
                            <b>Phone:</b>
                            <span>(+632) 887-2232</span>
                            <br>
                            <b>E-mail:</b>
                            <span>officialpnhs@pnhs.gov.ph</span>
                            <br>
                            </h6>
                        </div>
                        <div class="col-lg-3 col-md-3">
                            <h3 class="h3">FOLLOW US ON:</h3>
                            <a href="#"><i class="fa fa-bullseye w3-xlarge" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-phone w3-xlarge" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-facebook w3-xlarge" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-twitter w3-xlarge" aria-hidden="true"></i></a>
                            <a href="#"><i class="fa fa-google-plus w3-xlarge" aria-hidden="true"></i></a>
                        </div>
                    </div>
                </footer>