<!DOCTYPE html>
<html lang="en" >
   <?php
    //include("func.php");
    include("session.php");
	
	$qry= mysql_query("SELECT  monthname(time_issued) as month FROM  prs_mtr group by monthname(time_issued)");
	$qry1= mysql_query("SELECT year(time_issued) as year FROM  prs_mtr group by year(time_issued)"); 
 
	
    ?>
   <?php include("pages/headlink.php");?>
    <body>
        <div id="wrapper">
            <?php include("pages/sidenav.php"); ?>
            <?php include("pages/topnav.php")?>    
            <!---Start Content---->
				<div class="container">
                
                    <!--Body Start Here-->
					     
		<div class="container-fluid" style="height:700px;max-width:100%;margin-right:20px;margin-left:20px;margin-bottom:10px">
        
		
			<div class="row">
		<div class="col-lg-12">
		<h3 class="page-header"><i class="fa fa-laptop"></i> SUMMARY REPORT</h3>
		</div>
			</div>


                <!--======== CONTENT STARTS HERE=============-->			
				
				       <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel1">
                           <div style="width: 30%;">
						   <label class="col-sm-4 control-label"><font face="helvetica" size="5px"><b>YEAR:</b></font></label>
										<div class="form-group input-group">
										
								<select id="year_list" onChange="getYear(this.value)" class="form-control" required>
								<option>Select Year</option>
								<?php
								$year="";
								 while($row=mysql_fetch_assoc($qry1))
								 {	 
									 $ids =$row['prs_attendance_id'];
									 $year = $row['year'];
								?>
									<option value="<?php echo $year?>"><?php echo $year ?></option>
								 <?php }?>
								</select>
										</div>
							</div>
                        </div>
                        <!-- /.panel-heading -->
                        <div class="panel-body">
                        
			
<form>
					<table width="100%" class="table table-striped table-bordered table-hover" id="dataTables-example">

							    	<thead>
                                    <tr>
                                        <th><center>MONTH</center></th>
										<th><center>Total No. Of Recepients</center></th>
                                        
                                        
                                    </tr>
                                    </thead>
                                    
									<tbody>
     						
								<tr class="gradeA" id="month_list">
                                       <!--input hidden name="employee_id" id="employee_id" ></input-->
							
										<td></td>
                                        
										<td></td>
                                        
								</tr> 
						    </tbody>
                            
							</table>
                           <!-- /.table-responsive -->
</form>
                        </div>
                        <!-- /.panel-body -->
                    </div>
            </div>	
			
				<!--======== CONTENT ENDS HERE=============-->	

					
</div>
					
					<!--End Body Here-->
                </div>
           <!--End Content--->
			   
			   <?php include("pages/footer.php")?> <!--Footer-->
            </div>
            <script src='../js/jquery.min.js'></script>
            <script src='../js/bootstrap.min.js'></script>
            <script  src="../js/index.js"></script>
			
				<!-- DataTables JavaScript -->
    <script src="../vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="../vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
    <script src="../vendor/datatables-responsive/dataTables.responsive.js"></script>

	<!-- Page-Level Demo Scripts - Tables - Use for reference -->
    <script>
    $(document).ready(function() {
        $('#dataTables-example').DataTable({
            responsive: true
        });
    });
    </script>
	
	<script text="text/javascript" src="../jquery/jquery-migrate-1.4.1.js"></script>
	
	<script>
				function getYear(val)
				{
					 $.ajax({
						 type: "POST",
						 url: "getdata1.php",
						 data: 'year='+val,
						 success: function(data)
						 {
							 $("#month_list").html(data);
						 }
					 })
				}
				
	</script>
  
        </body>
    </html>